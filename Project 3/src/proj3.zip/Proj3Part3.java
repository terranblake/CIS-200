/*******************************************************************
* Proj3Part1.java
* <Terran Blake / C Friday / 7:30>
*
* This program, a dice game called Pig, is played between two AIs.
* The program will continue unless one of the players gets to 20
* points. If one person rolls a one, they lose all their points for
* that turn. Otherwise, the players total is continuously added up
* for each turn until someone wins. This is simply a simulation of
* the pre-coded computer AI. 
* 
* COMPUTER'S AI
* 
* The computer's AI works 
* because it is told to stop once it reaches the 4th turn,
* minimizing the chance of getting a 1. The 2nd and 3rd parameters 
* for the computer are telling it to stop if the turn total and the
* complete total are greater than 20, making it stop once it has
* enough points to win, while the 3rd is simply telling the
* computer to stop if the turn total is the max amount for 3 turns.
* 
* REASON WHY IT WORKS
* 
* All of these together make the computer flawless in regards to
* decision making and timing of moves, as well as understanding
* how close to a win it is. Other than the randomness of the 
* dice rolls, the computer has a great intuitive sense of the game.
*******************************************************************/

//Import statements
import java.util.Scanner;
import java.util.Random;

//Class declaration
public class Proj3Part3 {
	
   //Main declaration
   public static void main(String[] args) {
	   
	   //Variable declarations
	   int playerScore = 0, computerScore = 0;
	   int turnTotal = 0;
	   double totalTurns = 0, turnsTaken = 0, average = 0;
	   boolean turnOver = false, gameOver = true;
	   int dice = 0;
	   char decision = ' ';
	   
	   //Constant declaration
	   final double DICETOTAL = 20;

	   //Scanner and Random declarations
	   Scanner read  = new Scanner(System.in);
	   Random rand = new Random();
    
	   //Loop for 10 games
	   for (int simTotal = 1; simTotal <= 10;){ 
  		
    	  
		   while(gameOver == true) {

			   do {		
				   if (playerScore < 20) {
					   if (turnTotal < 12) {
						   decision = 'r';
  						
					   }
  					
				   } else if (turnTotal >= 12 || turnTotal + playerScore >= 20) {
					   decision = 's';
  					
				   }
  				
				   if (decision == 'r' || decision == 'R') {
					   dice = rand.nextInt(6) + 1;
					   turnTotal = dice + turnTotal;
  				
					   if (dice == 1) {
						   turnTotal = 0;
						   turnOver = true;
						   break;
  						
					   }
  					
				   } else if (decision == 's' || decision == 'S') {
					   computerScore += turnTotal;
					   turnTotal = 0;
					   turnOver = true;
					   break;
  					
				   }
  				
			   } while(turnOver == false); 
  				
			   turnOver = false;
  			
			   if (computerScore >= DICETOTAL) {
				   System.out.println("Player 1 wins");
				   gameOver = false;
				   break;
  				
			   }	
  				
			   do {
  				
				   decision = 'a';
				   System.out.print("Computer turn total is: " + turnTotal);
  				
				   if(playerScore < 20 || computerScore > playerScore) {
					   if(turnTotal < 10){
						   decision = 'r';
  					
					   }else if(turnTotal >= 10 || turnTotal + playerScore >= 20) {
						   decision = 's';
  						
					   }

					   if (decision == 'r' || decision == 'R') {
						   dice = rand.nextInt(6) + 1;
						   turnTotal = dice + turnTotal;
						   System.out.println(". Computer rolls.");
  			
						   if (dice == 1) {
							   totalTurns++;
							   turnsTaken++;
							   System.out.println("Computer rolled: 1");
							   turnTotal = 0;
							   turnOver = true;
							   break;
  							
						   } else {
							   System.out.println("Computer rolled: " + dice + "\n");
  							
						   }
  						
					   } else if (decision == 's' || decision == 'S') {
						   totalTurns++;
						   turnsTaken++;
						   System.out.print(". Computer stops. ");
						   playerScore += turnTotal;
						   turnTotal = 0;
						   turnOver = true;
						   break;
  						
					   }
				   }
  				
			   } while(turnOver == false);
  			
			   turnOver = false;
			   System.out.println("Turn over.");
			   System.out.println("Current score: Computer has " + playerScore + "\n");
  			
			   if (playerScore >= DICETOTAL) {
				   System.out.println("Game over. Computer took " + turnsTaken + " turns to reach 20 points.\n");
				   turnsTaken = 0;
				   average = totalTurns/simTotal;
				   simTotal++;
				   playerScore = 0;
  				
				   if (simTotal > 10) {	
	  					gameOver = false;
	  					turnOver = true;
	  					average = totalTurns/simTotal;
	  					System.out.println();
	  					System.out.printf("Simulation over. Computer ");
	  					System.out.printf("averaged %.2f", average);
	  					System.out.print(" turns to reach 20 points.");
	  					break;
  					
				   }
  				
				   gameOver = true;
				   break;
  				
  			}
  		}
      } 
   }
	}