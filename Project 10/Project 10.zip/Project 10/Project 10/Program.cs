﻿/**
*   This application, a C# Word Jumble game, uses
*   arrays and forms to organize a graphical
*   interface for the user to interact with.
*
*   This file specifically acts as an entry
*	point for application.
*
* @author Terran Blake
* @version Project 10
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_10
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
