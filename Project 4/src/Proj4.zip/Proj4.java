/*******************************************************************
* Proj4.java
* <Terran Blake / C Friday / 7:30>
*
*This program, a word guessing scramble game, uses arrays to store
*the words from the file that is used for input. The program then
*randomly scrambles the word and displays it to the user. If the
*user needs a hint, the program will give the location and the 
*letter for that location. Once the user has guessed the word,
*the program will print out the number of attempts it took to
*solve the word.
*******************************************************************/

//Import statements
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.io.*;
import java.lang.*;

//Class declaration
public class Proj4 {

	// Scanner declaration
	static Scanner read = new Scanner(System.in);

	// String variable declaration
	static String input, randomWord;
	static String originalWord, jumbledWord;
	static String userDecision;

	// Integer variable declaration
	static int randomNumber = 0, randomHintLocation = 0;
	static int arraySize = 0, wordLength = 0;
	static int calculatedPoints = 0;
	static int wordScore = 10, overallScore = 0;

	// Array declaration
	static char[] selectedWord;

	// Character declaration
	static char characterInput;

	// File & Reader declaration
	static String inputFileLocation;
	static BufferedReader bufferedReader;

	// String list declaration
	static List<String> words;

	// Boolean declaration
	static boolean gameOn = true;

	// Main method
	public static void main(String[] args) throws IOException {

		try {

			String inputFileName = SetDestinationFolder();
			bufferedReader = new BufferedReader(new FileReader(inputFileName));

			int numWords = Integer.parseInt(bufferedReader.readLine());
			words = new ArrayList<String>(numWords);

			for (int x = 0; x < numWords; x++) {
				words.add(bufferedReader.readLine());

			}

			while (gameOn = true) {

				String randomWord = GetRandomWord(bufferedReader);

				GetCharacterLength();

				for (int x = 0; x < wordLength; x++) {
					selectedWord[x] = new Character(randomWord.charAt(x));

				}

				JumbleWord(selectedWord);

				DisplayCurrentPuzzle(randomNumber);

			}

		} catch (FileNotFoundException e) {
			System.out.println("Unable to open file");

		}

	}

	// Method to return a random number
	private static String GetRandomWord(BufferedReader bufferedReader) throws NumberFormatException, IOException {
		randomNumber = ThreadLocalRandom.current().nextInt(0, words.size());
		randomWord = words.get(randomNumber);

		return randomWord;
	}

	// Method to ask for user input
	public static String GetFileName() {
		System.out.print("Enter in the text file containing words (Ex: words.txt): ");

		return read.nextLine();
	}

	// Method to set destination folder
	public static String SetDestinationFolder() {
		inputFileLocation = ("C:/Users/terra/Google Drive/Spring 2016 Classes/CIS 200/Projects/Project 4/"
				+ GetFileName());

		return inputFileLocation;
	}

	// Method to randomize word choice
	public static void GetRandomNumber(int randomNum) {
		randomNum = ThreadLocalRandom.current().nextInt(0, words.size());

		DisplayCurrentPuzzle(randomNum);
	}

	// Method to randomize letter for hint
	public static void JumbleWordForHint() {
		int hintPosition = ThreadLocalRandom.current().nextInt(0, randomWord.length());
		char hintCharacter = randomWord.charAt(hintPosition);

		System.out.println("\nThe letter at spot " + (hintPosition + 1) + " is " + hintCharacter);
		wordScore = wordScore / 2;

		DisplayCurrentPuzzle(randomNumber);

	}

	// Method to set original word
	public static String GetOriginal(String originalWord) {
		return originalWord = words.get(randomNumber);

	}

	// Method to swap array elements
	public static void exchangeLetters(char[] selectedWord, int i, int j) {
		char swap = selectedWord[i];
		selectedWord[i] = selectedWord[j];
		selectedWord[j] = swap;

	}

	// Method to jumble word
	public static void JumbleWord(char[] selectedWord) {
		int N = selectedWord.length;
		for (int i = 0; i < N; i++) {
			int r = i + (int) (Math.random() * (N - i)); // between i and N-1

			exchangeLetters(selectedWord, i, r);
		}
	}

	// Method to determine user entry
	public static void GetUserChoice(String userDecision) {
		System.out.print("Enter (g)uess, (n)ew word, (h)int, or (q)uit: ");
		input = read.nextLine();
		userDecision = input.substring(0);

		UserChoices(userDecision);
	}

	// Method to determine the next state of game
	public static void UserChoices(String userDecision) {
		if (userDecision.equalsIgnoreCase("g")) {

			GuessPuzzle();

		} else if (userDecision.equalsIgnoreCase("n")) {

			// NewPuzzle();

		} else if (userDecision.equalsIgnoreCase("h")) {

			HintPuzzle();

		} else if (userDecision.equalsIgnoreCase("q")) {

			QuitPuzzle();

		} else if (userDecision.equalsIgnoreCase("dev tools")) {
			System.out.print("\nCurrent puzzle: **" + randomWord + "**");
			System.out.println("\nCurrent points for word: " + wordScore);

			GetUserChoice(userDecision);

		} else {
			InvalidEntry();

		}

	}

	// Method to guess puzzle
	public static void GuessPuzzle() {
		System.out.print("\nEnter your guess: ");
		input = read.nextLine();

		DetermineEquality(input);

	}

	// Method to receive hints
	public static void HintPuzzle() {
		JumbleWordForHint();

	}

	// Method to quit game
	public static void QuitPuzzle() {
		System.out.println("\nGoodbye!");
		System.out.println("Final Score: " + overallScore);
		gameOn = false;

		System.exit(0);

	}

	// Method to determine equality of strings
	public static void DetermineEquality(String input) {
		if (input.equalsIgnoreCase(randomWord)) {
			overallScore += wordScore;

			DisplayWinner();

		} else {
			
			while (wordScore >= 0) {
			wordScore = wordScore - 1;

			DisplayLoser();

			}
		
		}

	}

	// Method to show success
	public static void DisplayWinner() {
		System.out.println("You guessed it!");
		System.out.println("Score for word: " + wordScore);
		System.out.println("Total score: " + overallScore);

	}

	// Method to show mistakes
	public static void DisplayLoser() {
		System.out.println("\nOops! Try again.");

		DisplayCurrentPuzzle(randomNumber);

	}

	// Method to determine the next state of game
	public static void InvalidEntry() {
		System.out.println("\nInvalid Choice - 'g', 'n' 'h' or 'q' only");

		DisplayCurrentPuzzle(randomNumber);

	}

	// Method to display the current puzzle
	public static void DisplayCurrentPuzzle(int randomNumber) {
		System.out.print("\nCurrent puzzle: ");

		for (int i = 0; i < selectedWord.length; i++) {
			System.out.print(selectedWord[i]);
		}

		System.out.println("\nCurrent points for word: " + wordScore);

		GetUserChoice(userDecision);
	}

	// Method to get length of word
	public static void GetCharacterLength() {
		input = words.get(randomNumber);
		wordLength = input.length();
		selectedWord = new char[wordLength];

	}

}